package com.example.craveexpress;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class RestaurantListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);

        RecyclerView recyclerView = findViewById(R.id.restaurantRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Temporary navigation for testing (replace with actual restaurant items)
        Button tempMenuButton = new Button(this);
        tempMenuButton.setText("Go to Menu");
        tempMenuButton.setOnClickListener(view -> {
            Intent intent = new Intent(RestaurantListActivity.this, MenuActivity.class);
            startActivity(intent);
        });

        // Add temporary button programmatically for navigation testing
        ((LinearLayout) recyclerView.getParent()).addView(tempMenuButton);
    }
}
