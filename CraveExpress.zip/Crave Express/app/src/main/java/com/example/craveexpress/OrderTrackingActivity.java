package com.example.craveexpress;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OrderTrackingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        ProgressBar progressBar = findViewById(R.id.progressBar);
        TextView trackingText = findViewById(R.id.trackingText);

        // Simulate order progress for demonstration (you can replace this with live updates)
        new Thread(() -> {
            for (int progress = 0; progress <= 100; progress += 10) {
                final int currentProgress = progress;
                runOnUiThread(() -> {
                    progressBar.setProgress(currentProgress);
                    trackingText.setText("Order Progress: " + currentProgress + "%");
                });

                try {
                    Thread.sleep(500); // Simulate a delay
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
