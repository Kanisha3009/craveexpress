package com.example.craveexpress;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        RecyclerView recyclerView = findViewById(R.id.menuRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Temporary navigation for testing (replace with actual menu items)
        Button tempCheckoutButton = new Button(this);
        tempCheckoutButton.setText("Go to Checkout");
        tempCheckoutButton.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, CheckoutActivity.class);
            startActivity(intent);
        });

        // Add temporary button programmatically for navigation testing
        ((LinearLayout) recyclerView.getParent()).addView(tempCheckoutButton);
    }
}
